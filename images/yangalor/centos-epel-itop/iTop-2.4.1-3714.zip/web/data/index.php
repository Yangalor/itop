<?php
echo 'Access denied';
